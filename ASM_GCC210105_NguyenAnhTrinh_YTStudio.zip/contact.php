<?php
require_once 'header.php'
?>
<article style = "text-align:center">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <h2 style="color:gray">
                            Store system information YT
                        </h2>
                        <p style="color:gainsboro">Posted by : Jesus  |   12/2/2022</p>
                        <h2>Store system</h2>
                        <h3>Ho Chi Minh branch</h3>
                        <p>561 Su Van Hanh, Ward 13, District 10</p>
                        <p>136 Nguyen Hong Dao, Ward 14, Tan Binh District</p>  
                        <p>The New Playground 26 Ly Tu Trong, Ben Nghe Ward, District 1</p>  
                        <p> Booth 36 Central Market 4 Pham Ngu Lao, Pham Ngu Lao Ward, District 1</p>  
                        <p>41 Quang Trung, Ward 3, Go Vap District</p> 
                        <p>---</p>
                        <h3>Ha Noi branch</h3>  
                        <p>49-51 Ho Dac Di, Nam Dong Ward, Dong Da District</p>
                        <p>---</p>
                        <h3>Can Tho branch</h3>
                        <p>52 Mau Than, An Phu Ward, Ninh Kieu District, City. Can Tho</p>
                        <p>---</p>
                        <h3>Da Nang branch
                        </h3>
                        <p>658 Ngo Quyen, An Hai Bac, Son Tra, Da Nang</p>
                        <p>---</p>
                        <h3>Soc Trang branch</h3>
                        <p>09 Ton Duc Thang, Ward 6, Soc Trang</p>
                        <br>
                        <p>0919723728 - 19001008</p>
                        <p>ytteamperfume@gmail.com</p>
                    </div>
                </div>
            </div>
        </article>
<?php
require_once 'footer.php'
?>
