<?php
require_once 'header.php'
?>
<article class = "container-fluid">
            <div class="row">
            <?php
             include_once 'connect1.php';
             $c=new connect();
             $dblink = $c->connectToMySQL();
             $sql= "select * from `at0510_product`";
             $re = $dblink->query($sql);
            //  $row1 =$re->fetch_row();
            //  echo $row1[2];
            //  $re->data_seek(0);
             if($re->num_rows>0):
                while($row=$re->fetch_assoc()):
            ?>

                <!-- <h1 id = "versace" style="text-align:center;">Versace</h1> -->
                <div class="card col-12 col-sm-6 col-md-4" style="width: 21rem;">
                    
                      <a href="detail.php?id=<?= $row['pid']?>" style="text-decoration:none;">
                      <img src="images/<?= $row['Image']?>" class="card-img-top" alt="..."  width="340" height="150">
                        <div class="card-body">
                        
                            <p class="card-text" style="color:black"><?=$row['Name'] ?></p>
                        
                          <a href="detail.php?id=<?= $row['pid']?>" class="btn btn-primary"><i class="bi bi-cart3"><?= $row['Price']?>$</i></a>
                        </div>
                      </a>
                    
                </div>
                  <?php
            endwhile;
             else:
             echo "Not found";
             endif;
             ?>
            </div>
</article>

<?php
require_once 'footer.php'
?>