<?php 
session_start();
ob_start();
unset($_SESSION['user_Name']);
header('location:homepage.php');
?>