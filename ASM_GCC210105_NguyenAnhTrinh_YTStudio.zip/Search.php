<?php
require_once 'header.php'
?>
<article class = "container-fluid">
<h2>Result for "<?= $_GET['search']?>"</h2>
<div class = "row">

<?php
 include_once 'connect1.php';
 $c=new connect();
 $dbsearch = $c->connectToPDO();
 $Name=$_GET['search']??'';
 $sql= "select * from at0510_product where Name like ?";
//  CONCAT('%',:Name,'%')"; // where $_GET['id'];
 $re = $dbsearch->prepare($sql);
//  $re->bindParam(":Name",$Name, PDO::PARAM_STR);
 $re->execute(array("%$Name%"));
 $rows = $re->fetchAll(PDO::FETCH_BOTH);
 foreach($rows as $r):
 //$row1 = $re->fetch_row();
 //echo $row1[2];
 //echo"<br>";
 //$re->data_seek(0);
 //if($re->num_rows>0):
 //   while($row=$re->fetch_assoc()):
?>

                <!-- <h1 id = "versace" style="text-align:center;">Versace</h1> -->
             
                <div class="card col-12 col-sm-6 col-md-4" style="width: 21rem;">
                    
                      <a href="detail.php?id=<?= $r['pid']?>" style="text-decoration:none;">
                      <img src="images/<?= $r['Image']?>" class="card-img-top" alt="..."  width="340" height="150">
                        <div class="card-body">
                            <p class="card-text" style="text-decoration:none;
                            color:black"><?=$r['Name'] ?></p>
                        
                          <a href="#" class="btn btn-primary"><i class="bi bi-cart3"><?= $r['Price']?>$</i></a>
                        </div>
                      </a>
                    
                  </div>
                  <?php
            endforeach;
             ?>
            </div>
          </div>
</article>

<?php
require_once 'footer.php'
?>