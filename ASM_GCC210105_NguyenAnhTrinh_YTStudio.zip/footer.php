<footer >
        <div class="container-fluid pt-2">
            <div class="row">
                <div class="col-12 ">
                    <div class="header">
                        <hr>
                        <p> 
                            <i class="bi bi-telephone" ></i>
                            Support/Buy: 0919723728
                        </p>
                       
                    </div>
                </div>
            </div>
        </div>
       <hr>
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-sm-6 col-md-4 ">
                    <h1>Store policy</h1>
                    <p>Privacy Policy<br>
                        FAQ<br>
                        Membership Card Policy<br>
                        Warranty & Return Policy</p>
                </div>
                <div class="col-12 col-sm-6 col-md-4 ">
                    <h1>Social</h1>
                   <a href="#"><i class="bi bi-facebook" style="color:black;"></i></a> 
                    <a href="#"><i class="bi bi-instagram" aria-hidden="true" style="color:black;"></i></a>
                    <a href="#"><i class="bi bi-twitter" aria-hidden="true" style="color:black;"></i></a>
                </div>
                <div class="col-12 col-sm-6 col-md-4 ">
                    <h1>Shop system</h1>
                    <i class="bi bi-geo-alt-fill" aria-hidden="true"> Can Tho</i><br>
                    <i class="bi bi-geo-alt-fill" aria-hidden="true"> Soc Trang</i><br>
                    <i class="bi bi-geo-alt-fill" aria-hidden="true"> TP.Ho Chi Minh</i><br>
                    <i class="bi bi-geo-alt-fill" aria-hidden="true"> Ha Noi</i><br>
                    <i class="bi bi-geo-alt-fill" aria-hidden="true"> Da Nang</i><br>
                </div>
            </div>
        </div>
      </footer>
      <late class="text-muted py-5" >
            <div class="container"> 
                <p class="float-end mb-1"><a href="#">Back to top</a> </p> 
                <p>&copy; 2017-2022 YT Seller Studio, <a href="#">Terms</a></p> Inc. 
                <a href="#">Privacy</a> &middot; &middot; </a>

            </div> 
      </late>
    </body>
    <script>
        $(document).ready(function(){
            let friend =["Louis Vuitton","Versace","Chanel"]
            $("#search").autocomplete({
                source:friend
            });
        })
    </script>
    </html> 